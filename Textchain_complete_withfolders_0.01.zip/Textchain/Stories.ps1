﻿function Story-Line([int]$storyStep) {
    
    switch ($storyStep) {
        1 {
            Char2 0
        }

        2 {$global:item.Add("PUMPKIN")}

    }
    "Story-Line Debug"
}